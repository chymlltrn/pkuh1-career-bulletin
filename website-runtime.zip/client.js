const search = document.getElementById('search');
const clear = document.getElementById('clear-search');
const count = document.getElementById('count');
const empty = document.getElementById('empty');
const cards = Array.from(document.querySelectorAll('.record')).map(el => ({ el, record: JSON.parse(el.dataset.filter) }));
const categoryButtons = Array.from(document.querySelectorAll('[data-category]'));
const locationScope = document.getElementById('location-scope');
const locationSelect = document.getElementById('location');
const dateMode = document.getElementById('date-mode');
const kind = document.getElementById('event-kind');
const from = document.getElementById('date-from');
const to = document.getElementById('date-to');
const reset = document.getElementById('reset-filters');
const error = document.getElementById('filter-error');
const sourceFilter = document.getElementById('source-filter');
let category = '';
function updateLocations() {
  const previous = locationSelect.value;
  const values = [...new Set(cards.flatMap(({record}) => locationScope.value === 'work' ? record.work : record.events.map(e => e.city)).filter(Boolean))].sort((a,b) => a.localeCompare(b, 'zh-CN'));
  locationSelect.replaceChildren();
  for (const [value, label] of [['', '全部地点'], ...values.map(v => [v,v]), ['__unknown__', '地点未注明']]) {
    const option = document.createElement('option'); option.value = value; option.textContent = label; locationSelect.append(option);
  }
  locationSelect.value = values.includes(previous) || previous === '__unknown__' ? previous : '';
}
function filterRecords() {
  const today = new Intl.DateTimeFormat('sv-SE', {timeZone:'Asia/Shanghai'}).format(new Date());
  const filters = { category, source: sourceFilter?.value || '', query: search.value, locationScope: locationScope.value, location: locationSelect.value, dateMode: dateMode.value, kind: kind.value, from: from.value, to: to.value, today };
  let visible = 0;
  for (const {el, record} of cards) { el.hidden = !matchesRecord(record, filters); if (!el.hidden) visible++; }
  count.textContent = `${visible} / ${cards.length} 条信息`;
  clear.hidden = !search.value; empty.hidden = visible > 0;
  const invalid = dateMode.value === 'custom' && from.value && to.value && from.value > to.value;
  error.hidden = !invalid;
  from.setAttribute('aria-invalid', String(Boolean(invalid))); to.setAttribute('aria-invalid', String(Boolean(invalid)));
  for (const button of categoryButtons) button.setAttribute('aria-pressed', String(button.dataset.category === category));
  document.getElementById('custom-dates').hidden = dateMode.value !== 'custom';
}
categoryButtons.forEach(button => button.addEventListener('click', () => { category = button.dataset.category; filterRecords(); }));
search.addEventListener('input', filterRecords);
clear.addEventListener('click', () => { search.value = ''; filterRecords(); search.focus(); });
[locationSelect, dateMode, kind, from, to].forEach(el => el.addEventListener('change', filterRecords));
sourceFilter?.addEventListener('change', filterRecords);
locationScope.addEventListener('change', () => { updateLocations(); filterRecords(); });
reset.addEventListener('click', () => { category = ''; if (sourceFilter) sourceFilter.value = ''; search.value = ''; locationScope.value = 'event'; dateMode.value = 'all'; kind.value = ''; from.value = ''; to.value = ''; updateLocations(); locationSelect.value = ''; filterRecords(); });
window.addEventListener('beforeprint', () => document.querySelectorAll('details').forEach(el => { el.dataset.wasOpen = String(el.open); if (!el.classList.contains('operations')) el.open = true; }));
window.addEventListener('afterprint', () => document.querySelectorAll('details').forEach(el => { el.open = el.dataset.wasOpen === 'true'; }));
updateLocations(); filterRecords();
