"""Validate public contributions, read public WeChat articles, and export XLSX.

This module only accepts records supplied by its caller. It never reads private
workflow data or makes GitHub requests. Imported notices remain unverified
community contributions even when the article was read automatically.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import http.client
import io
import ipaddress
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from html.parser import HTMLParser
from xml.etree import ElementTree as ET


CATEGORIES = {
    "hospital": "医院",
    "public_state": "公务员／国企",
    "pharma_company": "药企及其他企业",
}
EVENT_KINDS = {"application", "briefing", "assessment", "visit", "recruitment"}
SOURCE_LABEL = "同学补充 · 非企业微信官方群汇总"
WECHAT_GROUP_LABEL = "微信群汇总 · 非企业微信官方群汇总"
MAX_ORIGINAL_TEXT = 8000
MAX_ARTICLE_TEXT = 30000
MAX_ARTICLE_BYTES = 2 * 1024 * 1024
FIELD_LIMITS = {
    "source_url": 2048,
    "organization": 200,
    "category": 30,
    "recruitment_time": 2000,
    "original_text": MAX_ORIGINAL_TEXT,
    "message_date": 10,
    "event_start": 10,
    "event_end": 10,
    "event_kind": 30,
    "event_city": 100,
    "event_location": 500,
}
AUTH_QUERY_KEYS = {
    "key", "uin", "pass_ticket", "exportkey", "wxtoken", "wx_header",
    "access_token", "auth_token", "authorization", "session", "sessionid",
    "cookie", "ticket", "token", "code",
}
TRACKING_KEYS = {"from", "scene", "subscene", "srcid", "clicktime", "enterid", "spm", "fbclid", "gclid"}
ISSUE_URL = re.compile(r"https://github\.com/chymlltrn/pkuh1-career-bulletin/issues/[1-9][0-9]*\Z")
_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


class ValidationError(ValueError):
    """Safe, actionable input error suitable for a contribution status."""


class FetchError(ValueError):
    """Safe article-fetch error; never contains request credentials or HTML."""


def source_type(record):
    source = record.get("source_type", "official")
    if not isinstance(source, str) or source not in {"official", "wechat_group", "community"}:
        raise ValidationError("source_type 必须为 official、wechat_group 或 community。")
    if "source_group" in record:
        group = record["source_group"]
        if not isinstance(group, str) or not group.strip() or len(group) > 200 or re.search(r"[\x00-\x1f\x7f]", group):
            raise ValidationError("source_group 必须为有效的非空群名。")
    if source == "wechat_group" and not record.get("source_group"):
        raise ValidationError("微信群汇总必须提供 source_group 真实群名。")
    return source


def source_label(record):
    source = source_type(record)
    if source == "wechat_group":
        return WECHAT_GROUP_LABEL + "\n来源微信群：" + record["source_group"]
    if source == "community":
        return SOURCE_LABEL
    return "企业微信群汇总\n来源企业微信群：" + record.get("source_group", "北大医院研究生通知群")


def _text(value, name, limit, *, required=False):
    if not isinstance(value, str):
        raise ValidationError(f"{name}必须是文字。")
    value = value.replace("\r\n", "\n").replace("\r", "\n").strip()
    if _CONTROL.search(value) or any(0xD800 <= ord(char) <= 0xDFFF or ord(char) in {0xFFFE, 0xFFFF} for char in value):
        raise ValidationError(f"{name}含无法保存的控制字符，请重新粘贴。")
    if len(value) > limit:
        raise ValidationError(f"{name}最多 {limit} 字，请核对后重新提交。")
    if required and not value:
        raise ValidationError(f"请填写{name}。")
    return value


def _date(value, name):
    if not value:
        return ""
    if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", value):
        raise ValidationError(f"{name}请使用 YYYY-MM-DD 格式。")
    try:
        dt.date.fromisoformat(value)
    except ValueError as exc:
        raise ValidationError(f"{name}不是有效日期，请核对。") from exc
    return value


def canonical_source_url(value, *, wechat_only=False):
    """Return a credential-free public HTTPS URL with tracking removed.

    WeChat article identities retain only __biz/mid/idx/sn, or their opaque
    /s/TOKEN path. Manual sources are never fetched by this module.
    """
    value = _text(value, "来源链接", FIELD_LIMITS["source_url"], required=True)
    if re.search(r"[\s\\]", value):
        raise ValidationError("来源链接中不能有空格、换行或反斜杠。")
    try:
        parsed = urllib.parse.urlsplit(value)
        host = (parsed.hostname or "").lower()
        port = parsed.port
    except ValueError as exc:
        raise ValidationError("来源链接格式不正确，请复制完整的公开 HTTPS 链接。") from exc
    if parsed.scheme != "https" or parsed.username is not None or parsed.password is not None or port not in (None, 443):
        raise ValidationError("请使用不含账号密码的公开 HTTPS 链接。")
    if not host or not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?", host) or "." not in host:
        raise ValidationError("请使用公开网站链接。")
    if host.endswith((".localhost", ".local", ".internal", ".invalid", ".test", ".example")) or host in {"localhost", "example.com", "example.org", "example.net"}:
        raise ValidationError("本机、测试或内部网址不能作为公开来源。")
    try:
        ipaddress.ip_address(host)
    except ValueError:
        pass
    else:
        raise ValidationError("请使用公开网站域名，不接受 IP 地址来源。")
    # Numeric alternate IP forms are rejected as well.
    if re.fullmatch(r"[0-9.]+", host):
        raise ValidationError("请使用公开网站域名，不接受 IP 地址来源。")
    try:
        pairs = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True, max_num_fields=80)
    except ValueError as exc:
        raise ValidationError("来源链接参数过多或格式不正确，请重新复制公开分享链接。") from exc
    if any(key.lower() in AUTH_QUERY_KEYS for key, _ in pairs):
        raise ValidationError("链接含登录或验证参数，请从公众号文章的“复制链接”重新获取公开分享链接，或改为手动填写公开来源。")
    if host == "mp.weixin.qq.com":
        values = {}
        for key, item in pairs:
            if key in {"__biz", "mid", "idx", "sn"}:
                if key in values:
                    raise ValidationError("微信链接的文章参数重复，请重新复制分享链接。")
                values[key] = item
        if re.fullmatch(r"/s/[A-Za-z0-9_-]{8,128}", parsed.path):
            return "https://mp.weixin.qq.com" + parsed.path
        if parsed.path != "/s" or set(values) != {"__biz", "mid", "idx", "sn"}:
            raise ValidationError("请粘贴完整的微信公众号文章链接（/s/文章编号，或带 __biz、mid、idx、sn 的 /s 链接）。")
        if not re.fullmatch(r"[A-Za-z0-9+/=]{4,256}", values["__biz"]) or not re.fullmatch(r"[1-9][0-9]{0,29}", values["mid"]) or not re.fullmatch(r"[1-9][0-9]{0,4}", values["idx"]) or not re.fullmatch(r"[A-Fa-f0-9]{32}", values["sn"]):
            raise ValidationError("微信链接的文章参数不完整或无效，请重新复制公开分享链接。")
        values["sn"] = values["sn"].lower()
        query = urllib.parse.urlencode([(key, values[key]) for key in ("__biz", "mid", "idx", "sn")])
        return "https://mp.weixin.qq.com/s?" + query
    if wechat_only:
        raise ValidationError("自动读取目前只接受微信公众号的公开文章链接；其他来源请使用手动填写。")
    clean = [(key, item) for key, item in pairs if key.lower() not in TRACKING_KEYS and not key.lower().startswith("utm_")]
    return urllib.parse.urlunsplit(("https", host, parsed.path or "/", urllib.parse.urlencode(sorted(clean)), ""))


def validate_payload(payload):
    """Validate and copy user fields; no network, filesystem, or side effects."""
    if not isinstance(payload, dict):
        raise ValidationError("提交内容必须是一个招聘信息对象。")
    allowed = set(FIELD_LIMITS) | {"mode", "consent_public", "work_locations"}
    if set(payload) - allowed:
        raise ValidationError("提交内容含不支持的字段，请通过网页表单重新提交。")
    mode = payload.get("mode")
    if not isinstance(mode, str) or mode not in {"manual", "link"}:
        raise ValidationError("请选择链接读取或手动填写。")
    if payload.get("consent_public") is not True:
        raise ValidationError("请先确认内容可公开，且同意以同学补充信息展示。")
    result = {"mode": mode, "consent_public": True}
    for key, limit in FIELD_LIMITS.items():
        result[key] = _text(payload.get(key, ""), key, limit)
    result["source_url"] = canonical_source_url(result["source_url"], wechat_only=mode == "link")
    if mode == "manual":
        for key, name in (("organization", "招聘主体单位"), ("category", "招聘类别"), ("recruitment_time", "招聘时间说明（可明确填写“未注明”）"), ("original_text", "招聘原文")):
            if not result[key]:
                raise ValidationError(f"请填写{name}。")
    if result["category"] and result["category"] not in CATEGORIES:
        raise ValidationError("招聘类别必须选择医院、公务员／国企、药企及其他企业之一。")
    if result["event_kind"] and result["event_kind"] not in EVENT_KINDS:
        raise ValidationError("请选择有效的招聘时间类型。")
    for key, name in (("message_date", "消息日期"), ("event_start", "活动开始日期"), ("event_end", "活动结束日期")):
        result[key] = _date(result[key], name)
    if result["event_start"] and result["event_end"] and result["event_start"] > result["event_end"]:
        raise ValidationError("活动开始日期不能晚于结束日期。")
    if (result["event_start"] or result["event_end"]) and not result["event_kind"]:
        raise ValidationError("填写活动日期时，请同时选择对应的时间类型。")
    places = payload.get("work_locations", [])
    if not isinstance(places, list) or len(places) > 30:
        raise ValidationError("工作地点必须是最多 30 项的文字列表。")
    result["work_locations"] = list(dict.fromkeys(_text(place, "工作地点", 100, required=True) for place in places))
    return result


class _ArticleParser(HTMLParser):
    VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
    BLOCK = {"p", "div", "section", "article", "h1", "h2", "h3", "h4", "h5", "h6", "li", "ul", "ol", "table", "tr", "blockquote", "br", "hr"}
    IGNORE = {"script", "style", "noscript", "template", "svg"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.body = []
        self.title = []
        self.visible = []
        self.og_title = ""
        self.found_body = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        parent = self.stack[-1] if self.stack else ("", False, False, False)
        ignored = parent[3] or tag in self.IGNORE or "hidden" in attrs or attrs.get("aria-hidden") == "true"
        in_body = parent[1] or attrs.get("id") == "js_content"
        in_title = parent[2] or attrs.get("id") == "activity-name"
        if attrs.get("id") == "js_content" and not ignored:
            self.found_body = True
        if tag == "meta" and attrs.get("property", "").lower() == "og:title" and not ignored:
            self.og_title = attrs.get("content", "")
        if in_body and not ignored and tag in self.BLOCK:
            self.body.append("\n")
        if tag not in self.VOID:
            self.stack.append((tag, in_body, in_title, ignored))

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                context = self.stack[index]
                if context[1] and not context[3] and tag in self.BLOCK:
                    self.body.append("\n")
                del self.stack[index:]
                break

    def handle_data(self, data):
        context = self.stack[-1] if self.stack else ("", False, False, False)
        if context[3]:
            return
        self.visible.append(data)
        if context[1]:
            self.body.append(data)
        if context[2]:
            self.title.append(data)


def _plain(parts):
    text = "".join(parts).replace("\r\n", "\n").replace("\r", "\n").replace("\xa0", " ")
    return re.sub(r"\n{3,}", "\n\n", "\n".join(line.strip() for line in text.splitlines())).strip()


def parse_wechat_article(html, *, url):
    """Extract only article title and #js_content, with no script evaluation."""
    canonical = canonical_source_url(url, wechat_only=True)
    if not isinstance(html, str):
        raise FetchError("文章内容无法解码，请改为手动填写公开招聘文字。")
    if len(html.encode("utf-8")) > MAX_ARTICLE_BYTES * 2:
        raise FetchError("文章内容过大，请改为手动填写对应的公开招聘信息。")
    parser = _ArticleParser()
    try:
        parser.feed(html)
        parser.close()
    except Exception as exc:
        raise FetchError("无法解析这篇文章，请改为手动填写并保留来源链接。") from exc
    body = _plain(parser.body)
    title = _plain(parser.title) or _plain([parser.og_title])
    if not parser.found_body or not body:
        visible = _plain(parser.visible)
        if any(word in visible for word in ("验证", "环境异常", "访问过于频繁", "微信客户端", "无法访问")):
            raise FetchError("微信要求验证或限制了自动读取。请在微信中打开文章，再使用手动填写粘贴公开招聘文字；不会尝试绕过验证。")
        if any(word in visible for word in ("已被删除", "已被发布者删除", "停止访问", "违规", "不存在")):
            raise FetchError("文章已删除、失效或不可公开访问，请检查来源，或改为手动填写可公开的招聘信息。")
        raise FetchError("未找到可读取的微信文章正文（图片招聘通知也可能没有文字）。请手动填写招聘信息并保留来源链接。")
    if not title:
        raise FetchError("未读取到文章标题，无法可靠识别招聘单位，请改为手动填写。")
    try:
        title = _text(title, "文章标题", 500, required=True)
        body = _text(body, "文章正文", MAX_ARTICLE_TEXT, required=True)
    except ValidationError as exc:
        raise FetchError(f"{exc}自动读取不会截断原文，请手动填写对应的公开招聘信息。") from exc
    return {"title": title, "original_text": body, "url": canonical}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def fetch_wechat_article(url, *, opener=None, timeout=15, max_bytes=MAX_ARTICLE_BYTES):
    """Read at most 2 MB from public WeChat /s articles, never login endpoints.

    ``opener`` is an optional callable(request, timeout=...) used by offline
    fixtures. Real requests disable automatic redirects and send no cookies.
    """
    current = canonical_source_url(url, wechat_only=True)
    if not isinstance(timeout, (int, float)) or not 0 < timeout <= 15:
        raise ValueError("timeout must be greater than zero and at most 15 seconds")
    if not isinstance(max_bytes, int) or not 0 < max_bytes <= MAX_ARTICLE_BYTES:
        raise ValueError("max_bytes must be at most 2 MB")
    open_url = opener or urllib.request.build_opener(_NoRedirect()).open
    deadline = time.monotonic() + timeout
    seen = set()
    for _ in range(5):
        if current in seen:
            raise FetchError("微信文章发生循环跳转，请重新复制分享链接，或改为手动填写。")
        seen.add(current)
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise FetchError("微信文章读取超过 15 秒，请稍后重试，或改为手动填写。")
        request = urllib.request.Request(current, headers={"User-Agent": "PKUH1CareerBulletin/1.0 (public article reader)", "Accept": "text/html,application/xhtml+xml", "Accept-Encoding": "identity"})
        response = None
        try:
            try:
                response = open_url(request, timeout=remaining)
            except urllib.error.HTTPError as exc:
                if exc.code not in {301, 302, 303, 307, 308}:
                    raise
                response = exc
            code = getattr(response, "status", None) or response.getcode()
            actual = canonical_source_url(response.geturl(), wechat_only=True)
            if actual != current:
                raise FetchError("读取工具发生了未经核对的自动跳转，请改为手动填写。")
            if code in {301, 302, 303, 307, 308}:
                location = response.headers.get("Location")
                if not location:
                    raise FetchError("微信文章跳转缺少地址，请重新复制分享链接。")
                try:
                    current = canonical_source_url(urllib.parse.urljoin(current, location), wechat_only=True)
                except ValidationError as exc:
                    raise FetchError("微信跳转到了登录、验证或非文章页面，无法自动读取；请改为手动填写公开招聘文字。") from exc
                continue
            if code != 200:
                raise FetchError("微信文章暂时无法公开读取，请稍后重试或改为手动填写。")
            media_type = response.headers.get("Content-Type", "text/html").split(";", 1)[0].strip().lower()
            if media_type not in {"text/html", "application/xhtml+xml"}:
                raise FetchError("该链接没有返回微信文章，请检查链接或改为手动填写。")
            if response.headers.get("Content-Encoding", "identity").strip().lower() not in {"", "identity"}:
                raise FetchError("文章返回了不支持的压缩内容，请改为手动填写。")
            declared = response.headers.get("Content-Length", "")
            if declared.isdigit() and int(declared) > max_bytes:
                raise FetchError("文章页面超过 2 MB，未继续读取；请改为手动填写对应招聘信息。")
            chunks, size = [], 0
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise FetchError("微信文章读取超过 15 秒，请稍后重试，或改为手动填写。")
                # urllib's socket timeout normally applies per read. Tighten it
                # to the remaining total budget whenever its socket is exposed.
                sock = getattr(getattr(getattr(response, "fp", None), "raw", None), "_sock", None)
                if sock is not None:
                    sock.settimeout(remaining)
                chunk = response.read(min(65536, max_bytes + 1 - size))
                if not chunk:
                    break
                chunks.append(chunk)
                size += len(chunk)
                if size > max_bytes:
                    raise FetchError("文章页面超过 2 MB，未继续读取；请改为手动填写对应招聘信息。")
            if time.monotonic() > deadline:
                raise FetchError("微信文章读取超过 15 秒，请稍后重试，或改为手动填写。")
            data = b"".join(chunks)
            charset_match = re.search(r"charset\s*=\s*[\"']?([\w-]+)", response.headers.get("Content-Type", ""), re.I)
            charset = charset_match.group(1).lower() if charset_match else "utf-8"
            if charset not in {"utf-8", "utf8", "gbk", "gb2312", "gb18030"}:
                raise FetchError("文章文字编码无法识别，请改为手动填写。")
            try:
                html = data.decode(charset)
            except UnicodeDecodeError as exc:
                raise FetchError("文章文字无法完整解码，未保存不完整原文；请改为手动填写。") from exc
            return parse_wechat_article(html, url=current)
        except FetchError:
            raise
        except (urllib.error.URLError, http.client.HTTPException, TimeoutError, OSError, ValidationError) as exc:
            raise FetchError("微信文章暂时无法公开读取（可能需要验证或网络超时）。请稍后重试，或在微信打开后手动粘贴公开招聘文字。") from exc
        finally:
            if response is not None:
                response.close()
    raise FetchError("微信文章跳转过多，未继续读取；请重新复制文章链接或手动填写。")


def _infer_organization(title):
    title = re.sub(r"^\s*(?:【[^】]{1,12}】|\[[^\]]{1,12}\]|(?:招聘|校招|宣讲|公告|通知|招录)\s*[|｜:：])\s*", "", title)
    title = re.sub(r"^(?:20[0-9]{2}(?:年|届)?\s*)", "", title)
    names = re.findall(r"(?:^|[|｜:：!！；;，,\n])\s*([\u4e00-\u9fffA-Za-z0-9·（）()\-]{2,100}?(?:医院|有限责任公司|股份有限公司|有限公司|公司|人民政府|委员会|人力资源和社会保障局|卫生健康局))(?=20[0-9]{2}|[（(\s，,:：]|招聘|招录|公开|校园|秋季|春季|诚聘|人才|应届|$)", title)
    names = list(dict.fromkeys(name.strip() for name in names if not re.search(r"招聘|招募|邀请|加入|公告|通知|关于|重磅|^(?:全国|多家|各地|全市|各大)|(?:医院|公司).*(?:医院|公司)", name)))
    return names[0] if len(names) == 1 else ""


def _infer_category(organization, title, body=""):
    if "医院" in organization:
        return "hospital"
    evidence = title + "\n" + body
    if re.search(r"公务员|选调生|事业单位|国企|央企|国有企业", evidence) or re.search(r"人民政府|委员会|人力资源和社会保障局|卫生健康局", organization):
        return "public_state"
    # A bare company suffix says nothing about state ownership. Require
    # explicit industry or ownership evidence rather than defaulting a SOE to
    # the other-company category merely because its title omitted "国企".
    if re.search(r"公司$", organization) and re.search(r"药企|医药|制药|生物技术|生物科技|医疗器械|民营企业|民营公司|外资企业|外资公司", evidence):
        return "pharma_company"
    return ""


def _infer_explicit_dates(text):
    """Only full dates tied to an event on the same line become filter dates."""
    events, descriptions = [], []
    pattern = re.compile(r"(?<![0-9])([12][0-9]{3})(?:年|[-/.])([0-9]{1,2})(?:月|[-/.])([0-9]{1,2})日?(?![0-9])")
    for line in text.splitlines():
        kinds = [kind for kind, marker in (("application", r"报名|截止|申请"), ("briefing", r"宣讲"), ("assessment", r"考核|面试|笔试"), ("visit", r"参访"), ("recruitment", r"招聘会|招聘活动")) if re.search(marker, line)]
        if len(kinds) != 1:
            continue
        matches = list(pattern.finditer(line))
        if not 1 <= len(matches) <= 2:
            continue
        dates = []
        for match in matches:
            try:
                dates.append(dt.date(*map(int, match.groups())).isoformat())
            except ValueError:
                dates = []
                break
        if not dates:
            continue
        if len(dates) == 2 and not re.fullmatch(r"\s*(?:至|到|—|–|~|～|-)\s*", line[matches[0].end():matches[1].start()]):
            continue
        if dates[0] > dates[-1]:
            continue
        event = {"kind": kinds[0], "start": dates[0], "end": dates[-1], "city": "", "location": "未注明"}
        if event not in events:
            events.append(event)
            descriptions.append(line.strip())
    description = "\n".join(descriptions)
    return events, description if len(description) <= FIELD_LIMITS["recruitment_time"] else "招聘时间安排见原文（含多个明确日期）"


def record_from_payload(payload, *, article=None, submission_url=""):
    """Create one forced-community record from validated input and parsed text.

    Link mode must receive the result of parse/fetch_wechat_article. The caller
    owns stable issue-based IDs and can replace the deterministic URL-based ID.
    """
    data = validate_payload(payload)
    if not isinstance(submission_url, str) or not ISSUE_URL.fullmatch(submission_url):
        raise ValidationError("补充信息缺少有效的本站 GitHub 投稿记录，请通过网页重新提交。")
    title, body, resolved_url = "", data["original_text"], data["source_url"]
    if data["mode"] == "link":
        if not isinstance(article, dict):
            raise ValidationError("链接尚未成功读取，请等待处理结果或改为手动填写。")
        title = _text(article.get("title", ""), "文章标题", 500, required=True)
        body = _text(article.get("original_text", ""), "文章正文", MAX_ARTICLE_TEXT, required=True)
        resolved_url = canonical_source_url(article.get("url", ""), wechat_only=True)
    organization = data["organization"] or _infer_organization(title)
    category = data["category"] or _infer_category(organization, title, body)
    if not organization:
        raise ValidationError("文章已读取，但无法可靠识别招聘主体单位。请改为手动填写单位、类别、招聘时间说明和原文后提交。")
    if not category:
        raise ValidationError("文章已读取，但招聘类别不明确。请改为手动填写并选择类别；不会自动归入任意一类。")
    events, inferred_time = _infer_explicit_dates(body) if data["mode"] == "link" else ([], "")
    if data["event_start"] or data["event_end"]:
        events = [{"kind": data["event_kind"], "start": data["event_start"] or data["event_end"], "end": data["event_end"] or data["event_start"], "city": data["event_city"], "location": data["event_location"] or "未注明"}]
    elif data["event_kind"] or data["event_city"] or data["event_location"]:
        events = [{"kind": data["event_kind"], "start": None, "end": None, "city": data["event_city"], "location": data["event_location"] or "未注明"}]
    links = [{"label": "同学提供的招聘来源", "url": resolved_url}]
    if data["source_url"] != resolved_url:
        links.append({"label": "原始分享链接", "url": data["source_url"]})
    return {
        "id": "community-" + hashlib.sha256(data["source_url"].encode("utf-8")).hexdigest()[:16],
        "message_time": data["message_date"] or "未注明",
        "recruitment_time": data["recruitment_time"] or inferred_time or "未注明",
        "organization": organization,
        "original_text": body,
        "category": category,
        "recruitment_location": data["event_location"] or data["event_city"] or "未注明",
        "work_locations": data["work_locations"],
        "events": events,
        "links": links,
        "source_type": "community",
        "source_label": SOURCE_LABEL,
        "public_eligible": True,
        "review_status": "community_unverified",
        "submission_url": submission_url,
    }


def find_duplicate_record(source_url, records):
    """Find canonical source collisions across both public record collections."""
    wanted = canonical_source_url(source_url)
    for record in records:
        if record.get("public_eligible") is False:
            continue
        links = record.get("links", [])
        if not isinstance(links, list):
            links = [links]
        for link in links:
            url = link if isinstance(link, str) else link.get("url", "") if isinstance(link, dict) else ""
            try:
                if canonical_source_url(url) == wanted:
                    return record
            except (ValidationError, ValueError):
                continue
    return None


_SHEET_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _xml(element):
    return ET.tostring(element, encoding="utf-8", xml_declaration=True)


def _xlsx_chunks(value):
    """Keep every character while respecting Excel's UTF-16 cell limit."""
    if not isinstance(value, str):
        value = str(value or "")
    if _CONTROL.search(value) or any(0xD800 <= ord(char) <= 0xDFFF or ord(char) in {0xFFFE, 0xFFFF} for char in value):
        raise ValidationError("招聘原文含 Excel 无法表示的字符，未生成会丢失原文的文件。")
    chunks, current, size = [], [], 0
    for char in value:
        units = 2 if ord(char) > 0xFFFF else 1
        if size + units > 32767:
            chunks.append("".join(current))
            current, size = [], 0
        current.append(char)
        size += units
    chunks.append("".join(current))
    return chunks


def build_workbook(records):
    """Return a dependency-free eight-column public workbook as OOXML bytes.

    All values use inlineStr, so formulas and URLs cannot execute. Extremely
    long values use continuation rows without truncating their original text.
    """
    if not isinstance(records, list):
        raise ValidationError("Excel 输入必须是公开招聘记录列表。")
    if any(not isinstance(record, dict) or record.get("public_eligible") is False or record.get("restricted") is True for record in records):
        raise ValidationError("Excel 只能接收已公开的招聘记录，不能包含私有或受限通知。")
    ET.register_namespace("", _SHEET_NS)
    tag = lambda name: "{" + _SHEET_NS + "}" + name
    sheet = ET.Element(tag("worksheet"))
    views = ET.SubElement(sheet, tag("sheetViews"))
    view = ET.SubElement(views, tag("sheetView"), workbookViewId="0")
    ET.SubElement(view, tag("pane"), ySplit="1", topLeftCell="A2", activePane="bottomLeft", state="frozen")
    ET.SubElement(sheet, tag("sheetFormatPr"), defaultRowHeight="18")
    cols = ET.SubElement(sheet, tag("cols"))
    for index, width in enumerate((22, 42, 38, 22, 40, 100, 58, 42), 1):
        ET.SubElement(cols, tag("col"), min=str(index), max=str(index), width=str(width), customWidth="1")
    rows = ET.SubElement(sheet, tag("sheetData"))
    row_number = 0

    def append_row(values, style):
        nonlocal row_number
        row_number += 1
        row = ET.SubElement(rows, tag("row"), r=str(row_number))
        if row_number == 1:
            row.set("ht", "28")
            row.set("customHeight", "1")
        for index, value in enumerate(values):
            cell = ET.SubElement(row, tag("c"), r=f"{chr(65 + index)}{row_number}", t="inlineStr", s=str(style))
            text = ET.SubElement(ET.SubElement(cell, tag("is")), tag("t"))
            text.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            text.text = value

    append_row(["消息时间", "招聘时间", "招聘主体单位", "招聘类别", "招聘地点", "招聘原文", "来源链接", "信息来源"], 1)
    for record in records:
        source = source_type(record)
        label = source_label(record)
        raw_links = record.get("links", [])
        if not isinstance(raw_links, list):
            raw_links = [raw_links]
        links = []
        for link in raw_links:
            url = link if isinstance(link, str) else link.get("url", "") if isinstance(link, dict) else ""
            try:
                links.append(canonical_source_url(url))
            except ValidationError:
                # Older public records may have a damaged original link. Retain
                # it as inert text rather than silently modifying the provenance.
                if isinstance(url, str) and url:
                    links.append(url)
        places = record.get("work_locations", [])
        location = "活动：" + str(record.get("recruitment_location") or "未注明") + "\n工作：" + ("、".join(places) if places else "未注明")
        values = [str(record.get("message_time") or "未注明"), str(record.get("recruitment_time") or "未注明"), str(record.get("organization") or "未注明"), CATEGORIES.get(record.get("category"), "类别待核实"), location, str(record.get("original_text") or ""), "\n".join(dict.fromkeys(links)), label]
        chunks = [_xlsx_chunks(value) for value in values]
        for part in range(max(map(len, chunks))):
            values_part = [items[part] if part < len(items) else "" for items in chunks]
            if part:
                values_part[2] = values_part[2] or f"{record.get('organization') or '招聘信息'}（原文续行 {part + 1}）"
                values_part[7] = label
            append_row(values_part, 0 if source == "official" else 2)
    ET.SubElement(sheet, tag("autoFilter"), ref=f"A1:H{row_number}")
    ET.SubElement(sheet, tag("pageMargins"), left="0.25", right="0.25", top="0.5", bottom="0.5", header="0.2", footer="0.2")
    workbook = ET.Element(tag("workbook"), {"xmlns:r": _REL_NS})
    sheets = ET.SubElement(workbook, tag("sheets"))
    ET.SubElement(sheets, tag("sheet"), name="招聘汇总", sheetId="1", attrib={"r:id": "rId1"})
    styles = f'''<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="{_SHEET_NS}"><fonts count="3"><font><sz val="11"/><name val="Microsoft YaHei"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Microsoft YaHei"/></font><font><color rgb="FF8C2440"/><sz val="11"/><name val="Microsoft YaHei"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF8C2440"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF1DF"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1" applyFont="1" applyFill="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyAlignment="1" applyFont="1" applyFill="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'''
    content_types = '''<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'''
    root_rels = '''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'''
    workbook_rels = '''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'''
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in {"[Content_Types].xml": content_types, "_rels/.rels": root_rels, "xl/workbook.xml": _xml(workbook), "xl/_rels/workbook.xml.rels": workbook_rels, "xl/worksheets/sheet1.xml": _xml(sheet), "xl/styles.xml": styles}.items():
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, content)
    return output.getvalue()
