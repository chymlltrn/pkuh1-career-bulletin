// Kept dependency-free so the public exporter can include this module inline.
export function normalizeContribution(input = {}) {
  input = input && typeof input === 'object' ? input : {};
  const text = key => typeof input[key] === 'string' ? input[key].replace(/\r\n?/g, '\n').trim() : '';
  const mode = text('mode');
  const value = { mode, source_url: text('source_url'), consent_public: input.consent_public === true || input.consent_public === 'on' };
  const manual = mode === 'manual';
  for (const key of ['organization', 'category', 'recruitment_time', 'original_text', 'message_date', 'event_start', 'event_end', 'event_kind', 'event_city', 'event_location']) value[key] = manual ? text(key) : '';
  const places = Array.isArray(input.work_locations) ? input.work_locations : text('work_locations').split(/[、,，;；\n]/);
  value.work_locations = manual ? [...new Set(places.filter(place => typeof place === 'string').map(place => place.trim()).filter(Boolean))] : [];
  return value;
}

export function validateContribution(input = {}) {
  const value = normalizeContribution(input);
  const errors = {};
  const labels = { source_url: '公开来源链接', organization: '招聘主体单位', category: '招聘类别', recruitment_time: '招聘时间', original_text: '招聘原文', message_date: '消息发布日期', event_start: '开始日期', event_end: '结束日期', event_kind: '活动类型', event_city: '活动城市', event_location: '具体地点' };
  const limits = { source_url: 2048, organization: 200, recruitment_time: 2000, original_text: 8000, message_date: 10, event_start: 10, event_end: 10, event_city: 100, event_location: 500 };
  if (!['link', 'manual'].includes(value.mode)) errors.mode = '请选择添加方式。';
  for (const [key, limit] of Object.entries(limits)) if (value[key].length > limit) errors[key] = `${labels[key]}最多填写 ${limit} 个字符。`;
  if (!value.source_url) errors.source_url = '请填写公开来源链接。';
  else {
    let url;
    try { url = new URL(value.source_url); } catch {}
    // Public source articles need a domain name. Reject IP literals, local and
    // reserved hostnames; URL normalizes alternate numeric IP representations.
    const host = url?.hostname.replace(/\.$/, '').toLowerCase() || '';
    const privateHost = !host.includes('.') || host.includes(':') || /^\d+(?:\.\d+){3}$/.test(host) || /(?:^|\.)(?:localhost|local|internal|intranet|lan|home|test|invalid|example|onion)$/.test(host) || /(?:^|\.)(?:example\.(?:com|org|net)|localtest\.me|lvh\.me|nip\.io|sslip\.io)$/.test(host);
    if (!url || url.protocol !== 'https:' || url.username || url.password || (url.port && url.port !== '443') || privateHost || /[\u0000-\u0020\u007f\\]/.test(value.source_url)) errors.source_url = '请使用不含账号密码的公开网页 HTTPS 链接，不支持本机、IP 地址或内网来源。';
    else if (value.mode === 'link' && (url.protocol !== 'https:' || url.hostname !== 'mp.weixin.qq.com' || (url.port && url.port !== '443') || !/^\/s(?:\/[A-Za-z0-9_-]+)?\/?$/.test(url.pathname))) errors.source_url = '链接添加仅支持微信公众平台文章：https://mp.weixin.qq.com/s 或 /s/文章编号。其他公开来源请使用手动填写。';
    else if (url.hostname === 'mp.weixin.qq.com' && [...url.searchParams.keys()].some(key => /^(?:key|uin|pass_ticket|exportkey|wxtoken|ticket|sessionid|session_id|auth_token|access_token)$/i.test(key))) errors.source_url = '微信链接含登录或会话参数，请使用公众号文章的公开分享链接。';
    else if (!errors.source_url) value.source_url = url.href;
  }
  if (value.mode === 'manual') {
    for (const key of ['organization', 'category', 'recruitment_time', 'original_text']) if (!value[key]) errors[key] = `请填写${labels[key]}${key === 'recruitment_time' ? '；原文没有日期时填写“未注明”' : ''}。`;
    if (value.category && !['hospital', 'public_state', 'pharma_company'].includes(value.category)) errors.category = '请选择医院、公务员／国企或药企及其他企业。';
    if (value.event_kind && !['application', 'briefing', 'assessment', 'visit', 'recruitment'].includes(value.event_kind)) errors.event_kind = '请选择表单中的活动类型，无法确定时留空。';
    for (const key of ['message_date', 'event_start', 'event_end']) {
      const raw = value[key];
      const date = /^\d{4}-\d{2}-\d{2}$/.test(raw) ? new Date(raw + 'T00:00:00Z') : null;
      if (raw && (!date || !Number.isFinite(date.valueOf()) || date.toISOString().slice(0, 10) !== raw || raw < '1900-01-01' || raw > '2100-12-31')) errors[key] = `${labels[key]}须为 1900–2100 年内的真实日期，无法确定时留空。`;
    }
    if (value.event_start && value.event_end && !errors.event_start && !errors.event_end && value.event_start > value.event_end) errors.event_end = '结束日期不能早于开始日期。';
    if (value.work_locations.length > 30 || value.work_locations.some(place => place.length > 100)) errors.work_locations = '工作城市最多填写 30 个，每个最多 100 个字符。';
  }
  if (!value.consent_public) errors.consent_public = '请确认内容可公开展示且来源准确。';
  return { valid: Object.keys(errors).length === 0, errors, value };
}

export function renderContributionForm() {
  const input = (name, label, { required = false, type = 'text', max = 200, placeholder = '', help = '' } = {}) => `<label class="contribution-field" for="contribution-${name}"><span>${label} <small>${required ? '必填' : '选填'}</small></span><input id="contribution-${name}" name="${name}" type="${type}" ${required ? 'required' : ''} maxlength="${max}" ${type === 'date' ? 'min="1900-01-01" max="2100-12-31"' : ''} placeholder="${placeholder}" aria-describedby="contribution-${name}-help contribution-${name}-error"><span id="contribution-${name}-help" class="contribution-help">${help}</span><span id="contribution-${name}-error" class="contribution-error" hidden></span></label>`;
  const select = (name, label, options, required = false) => `<label class="contribution-field" for="contribution-${name}"><span>${label} <small>${required ? '必填' : '选填'}</small></span><select id="contribution-${name}" name="${name}" ${required ? 'required' : ''} aria-describedby="contribution-${name}-error"><option value="">${required ? '请选择' : '未注明／暂不填写'}</option>${options.map(([value, text]) => `<option value="${value}">${text}</option>`).join('')}</select><span id="contribution-${name}-error" class="contribution-error" hidden></span></label>`;
  return `<details id="contribution" class="contribution"><summary><span>补充招聘信息 <small>欢迎同学提供公开招聘线索</small></span><span class="contribution-toggle" aria-hidden="true"></span></summary><div class="contribution-body"><p class="contribution-badge">同学补充 · 非企业微信官方群汇总</p><p class="contribution-intro">补充信息将单独标记来源，字段校验通过后加入汇总。自动处理不代表老师核实。请只填写可以公开展示的招聘内容，不要填写私人联系方式、个人简历或仅限群内流转的信息。</p><form id="contribution-form" novalidate><fieldset class="contribution-modes"><legend>添加方式</legend><label><input type="radio" name="mode" value="link" checked> 微信推送链接</label><label><input type="radio" name="mode" value="manual"> 手动填写</label></fieldset><p id="contribution-link-note" class="contribution-help">只需粘贴公开微信推送链接并确认来源。提交后将自动处理链接，正文能否自动读取取决于微信页面访问情况；此处不会直接读取文章。</p><p class="contribution-help">继续后需登录 GitHub 并确认提交；处理结果可在提交记录中查看。不便使用 GitHub，或有疑问与需求，可邮件联系 <a href="mailto:honghaopeng@bjmu.edu.cn">honghaopeng@bjmu.edu.cn</a>。</p><p id="contribution-manual-note" class="contribution-help" hidden>必填项保留招聘关键信息与原文。没有明确日期时填写“未注明”，选填项留空即可，不作推测。</p>${input('source_url', '公开来源链接', { required: true, type: 'url', max: 2048, placeholder: 'https://mp.weixin.qq.com/s/…', help: '链接模式仅支持微信推送；手动模式支持招聘单位等公开 HTTPS 网页。' })}<fieldset id="contribution-manual" class="contribution-manual" disabled hidden><legend>招聘内容</legend><div class="contribution-grid">${input('organization', '招聘主体单位', { required: true, max: 200, placeholder: '例如：某医院／某公司' })}${select('category', '招聘类别', [['hospital', '医院'], ['public_state', '公务员／国企'], ['pharma_company', '药企及其他企业']], true)}<div class="contribution-wide">${input('recruitment_time', '招聘时间（原文）', { required: true, max: 2000, placeholder: '粘贴报名／宣讲等时间；没有则填写“未注明”', help: '保留原文中的时间条件，多个场次可一并填写。' })}</div><label class="contribution-field contribution-wide" for="contribution-original_text"><span>招聘原文 <small>必填</small></span><textarea id="contribution-original_text" name="original_text" rows="7" required maxlength="8000" placeholder="粘贴可公开的招聘通知正文，最多 8000 个字符" aria-describedby="contribution-original_text-error"></textarea><span id="contribution-original_text-error" class="contribution-error" hidden></span></label></div><details class="contribution-optional"><summary>补充时间与地点 <span>选填</span></summary><div class="contribution-grid">${input('message_date', '消息发布日期', { type: 'date', max: 10 })}${select('event_kind', '活动类型', [['application', '报名／截止'], ['briefing', '宣讲'], ['assessment', '考核'], ['visit', '参访'], ['recruitment', '招聘活动']])}${input('event_start', '开始日期', { type: 'date', max: 10, help: '与所选活动对应；不使用消息发布日期代替。' })}${input('event_end', '结束日期', { type: 'date', max: 10, help: '只有截止日期时可仅填写此项。' })}${input('event_city', '活动城市', { max: 100, placeholder: '例如：北京市' })}${input('event_location', '活动具体地点', { max: 500, placeholder: '例如：某校区某教室' })}<div class="contribution-wide">${input('work_locations', '工作城市', { max: 3029, placeholder: '多个城市用逗号分隔', help: '与宣讲地点分开填写；最多 30 个城市。' })}</div></div></details></fieldset><label class="contribution-consent" for="contribution-consent_public"><input id="contribution-consent_public" name="consent_public" type="checkbox" required aria-describedby="contribution-consent_public-error"><span>我确认上述内容可公开展示，来源准确，并同意以“同学补充 · 非企业微信官方群汇总”标记。</span></label><p id="contribution-consent_public-error" class="contribution-error" hidden></p><p id="contribution-errors" class="contribution-error" role="alert" hidden></p><section id="contribution-preview" class="contribution-preview" aria-labelledby="contribution-preview-title" hidden><h3 id="contribution-preview-title">提交前预览</h3><p class="contribution-badge">同学补充 · 非企业微信官方群汇总</p><div id="contribution-preview-content"></div></section><div class="contribution-actions"><button id="contribution-preview-button" type="button" disabled>预览内容</button><button id="contribution-submit" type="submit" disabled>继续提交</button></div><p id="contribution-status" class="contribution-help" role="status" aria-live="polite">请启用 JavaScript 后使用补充信息表单。</p></form></div></details>`;
}

export function installContributionForm(document, window, { onSubmit } = {}) {
  const form = document.getElementById('contribution-form');
  if (!form) return null;
  if (form.contributionController) return form.contributionController;
  const byId = id => document.getElementById('contribution-' + id);
  const field = name => form.elements.namedItem(name);
  const names = ['source_url', 'organization', 'category', 'recruitment_time', 'original_text', 'message_date', 'event_start', 'event_end', 'event_kind', 'event_city', 'event_location', 'work_locations', 'consent_public'];
  const status = byId('status'), submit = byId('submit');
  let busy = false;
  function read() {
    const input = { mode: field('mode').value };
    for (const name of names) input[name] = name === 'consent_public' ? field(name).checked : field(name).value;
    return input;
  }
  function errors(messages = {}) {
    for (const name of names) {
      const target = field(name), hint = byId(name + '-error');
      target.removeAttribute('aria-invalid');
      if (hint) { hint.hidden = !messages[name]; hint.textContent = messages[name] || ''; }
      if (messages[name]) target.setAttribute('aria-invalid', 'true');
    }
    byId('errors').textContent = Object.values(messages).length ? '请修改后再继续：' + Object.values(messages).join(' ') : '';
    byId('errors').hidden = !Object.keys(messages).length;
  }
  function modeChanged() {
    const manual = field('mode').value === 'manual';
    byId('manual').hidden = !manual;
    byId('manual').disabled = !manual;
    byId('link-note').hidden = manual;
    byId('manual-note').hidden = !manual;
    byId('preview').hidden = true;
    errors();
  }
  function preview(value = normalizeContribution(read())) {
    const categories = { hospital: '医院', public_state: '公务员／国企', pharma_company: '药企及其他企业' };
    const kinds = { application: '报名／截止', briefing: '宣讲', assessment: '考核', visit: '参访', recruitment: '招聘活动' };
    const lines = [`添加方式：${value.mode === 'manual' ? '手动填写' : '微信推送链接'}`, `公开来源：${value.source_url || '未填写'}`];
    if (value.mode === 'manual') lines.push(`招聘主体单位：${value.organization || '未填写'}`, `招聘类别：${categories[value.category] || '未填写'}`, `招聘时间：${value.recruitment_time || '未填写'}`, `消息发布日期：${value.message_date || '未注明'}`, `活动类型：${kinds[value.event_kind] || '未注明'}`, `开始日期：${value.event_start || '未注明'}`, `结束日期：${value.event_end || '未注明'}`, `活动城市：${value.event_city || '未注明'}`, `具体地点：${value.event_location || '未注明'}`, `工作城市：${value.work_locations.join('、') || '未注明'}`, '', '招聘原文：', value.original_text || '未填写');
    else lines.push('', '文章正文尚未读取，提交后将尝试自动读取并校验字段。');
    byId('preview-content').textContent = lines.join('\n');
    byId('preview').hidden = false;
  }
  byId('preview-button').disabled = false;
  submit.disabled = typeof onSubmit !== 'function';
  status.textContent = typeof onSubmit === 'function' ? '请先预览内容。点击“继续提交”后需登录 GitHub 并确认；打开页面并不表示已提交。' : '提交入口暂不可用，可先预览并通过页面邮箱联系整理者。';
  form.addEventListener('change', event => { if (event.target.name === 'mode') modeChanged(); });
  form.addEventListener('input', () => { byId('preview').hidden = true; });
  byId('preview-button').addEventListener('click', () => preview());
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (busy) return;
    const result = validateContribution(read());
    errors(result.errors);
    if (!result.valid) {
      const first = Object.keys(result.errors).find(name => field(name)?.focus);
      if (first) {
        const target = field(first), disclosure = target.closest?.('details');
        if (disclosure) disclosure.open = true;
        target.focus();
      }
      status.textContent = '内容尚未提交，请检查必填项目。';
      return;
    }
    preview(result.value);
    if (typeof onSubmit !== 'function') return;
    busy = true;
    submit.disabled = true;
    submit.setAttribute('aria-busy', 'true');
    status.textContent = '正在准备提交内容…';
    try {
      const response = await onSubmit(result.value);
      status.textContent = typeof response?.message === 'string' ? response.message : '内容已准备，请在打开的提交页面核对并确认。尚未确认提交完成。';
    } catch {
      status.textContent = '暂时无法继续提交，填写内容已保留。请稍后重试，或通过页面邮箱联系整理者。';
    } finally {
      busy = false;
      submit.disabled = false;
      submit.removeAttribute('aria-busy');
    }
  });
  modeChanged();
  form.contributionController = { read, preview };
  return form.contributionController;
}
