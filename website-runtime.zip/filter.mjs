export const CATEGORIES = { hospital: '医院', public_state: '公务员／国企', pharma_company: '药企及其他企业' };
export const EVENT_KINDS = { application: '报名／截止', briefing: '宣讲', assessment: '考核', visit: '参访', recruitment: '招聘活动' };
export const SOURCE_TYPES = { official: '企业微信群汇总', wechat_group: '微信群汇总', community: '同学补充' };
export function sourceType(record) {
  const source = Object.hasOwn(record, 'source_type') ? record.source_type : 'official';
  if (typeof source !== 'string' || !Object.hasOwn(SOURCE_TYPES, source)) throw new Error('source_type 必须为 official、wechat_group 或 community');
  if (Object.hasOwn(record, 'source_group') && (typeof record.source_group !== 'string' || !record.source_group.trim() || record.source_group.length > 200 || /[\u0000-\u001f\u007f]/.test(record.source_group))) throw new Error('source_group 必须为有效的非空群名');
  if (source === 'wechat_group' && !record.source_group) throw new Error('微信群汇总必须提供 source_group 真实群名');
  return source;
}
export function sourceCounts(records) {
  const counts = { official_records: 0, wechat_group_records: 0, community_records: 0 };
  for (const record of records) counts[`${sourceType(record)}_records`]++;
  return counts;
}
export function validDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const date = new Date(value + 'T00:00:00Z');
  return Number.isFinite(date.valueOf()) && date.toISOString().slice(0, 10) === value ? value : null;
}
export function filterable(record) {
  const events = (Array.isArray(record.events) ? record.events : []).map(event => ({
    kind: Object.hasOwn(EVENT_KINDS, event.kind) ? event.kind : '',
    start: validDate(event.start), end: validDate(event.end),
    city: typeof event.city === 'string' ? event.city.trim() : '',
    location: typeof event.location === 'string' ? event.location : '',
  }));
  const work = (Array.isArray(record.work_locations) ? record.work_locations : []).filter(v => typeof v === 'string' && v.trim());
  const source = sourceType(record);
  const search = ['organization', 'message_time', 'recruitment_time', 'recruitment_location', 'original_text', 'source_group'].map(key => record[key] || '').concat(work, events.map(e => e.location), CATEGORIES[record.category] || '', SOURCE_TYPES[source]).join('\n').toLocaleLowerCase('zh-CN');
  return { category: Object.hasOwn(CATEGORIES, record.category) ? record.category : '', source, events, work, search };
}
export function dateWindow(mode, from, to, today) {
  if (mode === 'custom') return { from: validDate(from), to: validDate(to) };
  if (mode === '7' || mode === '30') {
    const end = new Date(today + 'T00:00:00Z');
    end.setUTCDate(end.getUTCDate() + Number(mode) - 1);
    return { from: today, to: end.toISOString().slice(0, 10) };
  }
  return { from: null, to: null };
}
export function matchesRecord(record, filters) {
  if (filters.category && filters.category !== record.category) return false;
  if (filters.source && filters.source !== (record.source || 'official')) return false;
  const words = (filters.query || '').trim().toLocaleLowerCase('zh-CN').split(/\s+/).filter(Boolean);
  if (!words.every(word => record.search.includes(word))) return false;
  const placeMatch = city => !filters.location || (filters.location === '__unknown__' ? !city : city === filters.location);
  if (filters.locationScope === 'work' && filters.location && !(record.work.length ? record.work : ['']).some(placeMatch)) return false;
  const window = dateWindow(filters.dateMode, filters.from, filters.to, filters.today);
  if (window.from && window.to && window.from > window.to) return false;
  const needEvent = filters.kind || filters.dateMode === 'unknown' || window.from || window.to || (filters.locationScope !== 'work' && filters.location);
  if (!needEvent) return true;
  return (record.events.length ? record.events : [{kind: '', start: null, end: null, city: ''}]).some(event => {
    if (filters.kind && filters.kind !== event.kind) return false;
    if (filters.locationScope !== 'work' && !placeMatch(event.city)) return false;
    const start = event.start || event.end, end = event.end || event.start;
    if (filters.dateMode === 'unknown') return !start && !end;
    if ((window.from || window.to) && !start) return false;
    return (!window.from || end >= window.from) && (!window.to || start <= window.to);
  });
}
