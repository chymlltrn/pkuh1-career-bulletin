"""Reconcile public GitHub issues; never execute or interpolate submission text."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import urllib.error
import urllib.request

from community import (ValidationError, FetchError, validate_payload, record_from_payload,
                       fetch_wechat_article, find_duplicate_record, build_workbook)

REPOSITORY = 'chymlltrn/pkuh1-career-bulletin'
PAGE = 'https://chymlltrn.github.io/pkuh1-career-bulletin/'
MARKER = '<!-- recruitment-submission:v1 -->'
STATUS_MARKER = '<!-- recruitment-result:v1 -->'


def parse_issue(body):
    if not isinstance(body, str) or len(body) > 60000 or not body.startswith(MARKER):
        raise ValidationError('请使用招聘网页的“补充招聘信息”表单生成提交内容。')
    blocks = re.findall(r'^```json\s*\n(.*?)\n```\s*$', body, re.M | re.S)
    if len(blocks) != 1:
        raise ValidationError('提交内容格式不完整，请回到网页重新生成并替换正文。')
    try:
        payload = json.loads(blocks[0])
    except (ValueError, TypeError):
        raise ValidationError('提交内容不是有效格式，请回到网页重新生成。') from None
    return validate_payload(payload)


def reconcile(issues, official, previous, *, fetch_article=fetch_wechat_article, retry_number=None):
    """Scan all open submissions so a superseded queued run cannot lose an issue."""
    entries, records = {}, []
    for issue in sorted(issues, key=lambda item: item['number']):
        if issue.get('pull_request') or issue.get('state') != 'open':
            continue
        body = issue.get('body') or ''
        if not body.startswith(MARKER) and not str(issue.get('title', '')).startswith('[招聘补充]'):
            continue
        number = issue['number']
        if type(number) is not int or number < 1:
            raise ValueError('Invalid issue number')
        key = str(number)
        digest = hashlib.sha256(body.encode('utf-8')).hexdigest()
        entry = {'payload_hash': digest, 'issue_number': number}
        prior = previous.get(key, {})
        try:
            payload = parse_issue(body)
            duplicate = find_duplicate_record(payload['source_url'], official + records)
            if duplicate:
                entry.update(status='duplicate', message='对应来源已收录，本次没有重复添加。可在网页搜索单位名称查看。')
            else:
                if prior.get('payload_hash') == digest and prior.get('status') == 'ready' and prior.get('record'):
                    record = prior['record']
                elif prior.get('payload_hash') == digest and prior.get('status') == 'needs_details' and retry_number != number:
                    entry.update(status='needs_details', message=prior['message'])
                    entries[key] = entry
                    continue
                else:
                    article = fetch_article(payload['source_url']) if payload['mode'] == 'link' else None
                    record = record_from_payload(payload, article=article,
                        submission_url=f'https://github.com/{REPOSITORY}/issues/{number}')
                # A share URL may resolve to a different article identity already present.
                if any(find_duplicate_record(link if isinstance(link, str) else link['url'], official + records)
                       for link in record.get('links', [])):
                    entry.update(status='duplicate', message='对应来源已收录，本次没有重复添加。可在网页搜索单位名称查看。')
                    entries[key] = entry
                    continue
                # These labels are controlled by the service, never by a submitted field.
                record = dict(record, id=f'community-{number}', source_type='community',
                    source_label='同学补充 · 非企业微信官方群汇总', review_status='community_unverified',
                    submission_url=f'https://github.com/{REPOSITORY}/issues/{number}', public_eligible=True)
                entry.update(status='ready', record=record)
                records.append(record)
        except (ValidationError, FetchError) as error:
            entry.update(status='needs_details', message=str(error))
        entries[key] = entry
    return entries, records


class GitHub:
    def __init__(self, token):
        self.token = token

    def request(self, path, *, method='GET', body=None):
        if not path.startswith('/') or '..' in path:
            raise ValueError('Invalid API path')
        headers = {'Accept': 'application/vnd.github+json', 'X-GitHub-Api-Version': '2026-03-10',
                   'User-Agent': 'pkuh1-career-bulletin'}
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'
        payload = None if body is None else json.dumps(body, ensure_ascii=False).encode()
        if payload is not None:
            headers['Content-Type'] = 'application/json'
        request = urllib.request.Request(f'https://api.github.com/repos/{REPOSITORY}{path}',
                                         data=payload, headers=headers, method=method)
        # GitHub API paths are fixed by this program; no submitted URL receives the token.
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.load(response)

    def list_all(self, path):
        result = []
        for page in range(1, 21):
            values = self.request(path + ('&' if '?' in path else '?') + f'per_page=100&page={page}')
            if not isinstance(values, list):
                raise RuntimeError('GitHub 返回的数据格式异常，保留上一版网页。')
            result.extend(values)
            if len(values) < 100:
                return result
        raise RuntimeError('提交记录超过当前处理上限，保留上一版网页并请维护者扩容。')

    def set_status(self, number, message):
        comments = self.list_all(f'/issues/{number}/comments')
        existing = next((item for item in comments
            if item.get('user', {}).get('login') == 'github-actions[bot]'
            and (item.get('body') or '').startswith(STATUS_MARKER)), None)
        body = STATUS_MARKER + '\n' + message
        if existing and existing.get('body') == body:
            return
        if existing:
            self.request(f'/issues/comments/{int(existing["id"])}', method='PATCH', body={'body': body})
        else:
            self.request(f'/issues/{number}/comments', method='POST', body={'body': body})


def previous_state():
    request = urllib.request.Request(PAGE + 'community-state.json', headers={'Cache-Control': 'no-cache'})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read(20_000_001)
    except urllib.error.HTTPError as error:
        if error.code == 404:
            return {}
        raise
    if len(data) > 20_000_000:
        raise RuntimeError('已发布投稿数据过大，保留上一版网页。')
    state = json.loads(data)
    if state.get('schema_version') != 1 or not isinstance(state.get('entries'), dict):
        raise RuntimeError('已发布投稿数据无效，保留上一版网页。')
    return state['entries']


def save_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'announce'])
    parser.add_argument('--offline-issues')
    parser.add_argument('--offline-previous')
    args = parser.parse_args()
    api = GitHub(os.environ.get('GH_TOKEN'))
    if args.command == 'announce':
        state = json.loads(Path('_site/community-state.json').read_text())
        for number, entry in state['entries'].items():
            if entry['status'] == 'ready':
                message = f'已添加到[招聘汇总网页]({PAGE})及 Excel，并标记“同学补充 · 非企业微信官方群汇总”。\n\n这表示字段校验通过，并不代表群内老师已核实。编辑本条正文可更正；关闭本条提交可撤下对应补充信息。'
            else:
                message = entry['message'] + f'\n\n需要补填时，请到[招聘网页]({PAGE}#contribution)选择“手动填写”，重新生成后替换本条正文；也可邮件联系 honghaopeng@bjmu.edu.cn。'
            api.set_status(int(number), message)
        return
    official = json.loads(Path('official-records.json').read_text())
    if any(record.get('public_eligible') is False or record.get('source_type') == 'community' for record in official['records']):
        raise RuntimeError('群内公开快照资格异常，已停止发布。')
    if args.offline_issues:
        issues = json.loads(Path(args.offline_issues).read_text())
        previous = json.loads(Path(args.offline_previous).read_text()) if args.offline_previous else {}
    else:
        issues = api.list_all('/issues?state=open&sort=created&direction=asc')
        previous = previous_state()
    event = json.loads(Path(os.environ['GITHUB_EVENT_PATH']).read_text()) if os.environ.get('GITHUB_EVENT_PATH') else {}
    retry = event.get('issue', {}).get('number')
    entries, additions = reconcile(issues, official['records'], previous, retry_number=retry)
    meta = dict(official.get('meta', {}), published_at=datetime.now(timezone.utc).isoformat())
    data = {'meta': meta, 'records': official['records'] + additions}
    Path('_site').mkdir(exist_ok=True)
    save_json('_build-records.json', data)
    save_json('_site/community-state.json', {'schema_version': 1, 'entries': entries})
    Path('_site/recruitment.xlsx').write_bytes(build_workbook(data['records']))
    print(json.dumps({'official': len(official['records']), 'community': len(additions),
                      'needs_details': sum(e['status'] == 'needs_details' for e in entries.values()),
                      'duplicates': sum(e['status'] == 'duplicate' for e in entries.values())}))


if __name__ == '__main__':
    main()
