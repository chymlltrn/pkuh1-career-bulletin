import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { renderPage } from './render.mjs';
import { sourceCounts } from './filter.mjs';

const data = JSON.parse(await readFile('_build-records.json', 'utf8'));
const url = 'https://chymlltrn.github.io/pkuh1-career-bulletin/';
const html = await renderPage(data, { excelHref: 'recruitment.xlsx', publicUrl: url });
await mkdir('_site', { recursive: true });
await writeFile('_site/index.html', html);
await writeFile('_site/.nojekyll', '');
const files = {};
for (const name of ['index.html', 'recruitment.xlsx', 'community-state.json']) {
  files[name] = createHash('sha256').update(await readFile(`_site/${name}`)).digest('hex');
}
await writeFile('_site/site-manifest.json', JSON.stringify({
  records: data.records.length,
  ...sourceCounts(data.records),
  commit: process.env.GITHUB_SHA || null,
  run_id: process.env.GITHUB_RUN_ID || null,
  files,
}, null, 2) + '\n');
console.log(JSON.stringify({ records: data.records.length, files }));
