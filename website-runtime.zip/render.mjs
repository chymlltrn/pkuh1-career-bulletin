import { readFile } from 'node:fs/promises';
import { CATEGORIES, EVENT_KINDS, filterable, sourceCounts } from './filter.mjs';
import { STATISTICS_PAGE, STATISTICS_API } from './statistics.mjs';
import { renderContributionForm } from './contribute.mjs';
export const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
export function safeWebUrl(value) {
  if (typeof value !== 'string' || /[\u0000-\u0020\u007f]/.test(value)) return null;
  try { const url = new URL(value); return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password ? url.href : null; } catch { return null; }
}
export async function renderPage(data, { excelHref = null, adminHtml = '', qrImages = {}, publicUrl = null } = {}) {
  const records = data.records;
  const css = await readFile(new URL('./theme.css', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./contribute.css', import.meta.url), 'utf8');
  const { official_records: officialCount, wechat_group_records: wechatCount, community_records: communityCount } = sourceCounts(records);
  const client = await readFile(new URL('./filter.mjs', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./client.js', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./transfer.mjs', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./statistics.mjs', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./contribute.mjs', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./submission.mjs', import.meta.url), 'utf8') + '\ninstallSubmission(document, window);\nconst statistics = installStatistics(document, window);\ninstallTransfers(document, window, { onDownloadStarted: statistics.downloadStarted });';
  const range = data.meta?.range || '时间范围未注明';
  const download = excelHref ? `<div class="download-tools">
    <div class="download-actions"><a id="download-excel" class="download" href="${escapeHtml(excelHref)}" download="2026-2027 秋招春招汇总.xlsx" aria-describedby="download-status">下载 Excel <span aria-hidden="true">↓</span></a>
    <details class="download-menu"><summary>下载选项</summary><div class="download-options"><a id="download-direct" href="${escapeHtml(excelHref)}" target="_blank" rel="noopener">备用下载</a><button id="copy-download-link" type="button" hidden>复制下载链接</button></div></details></div>
    <p id="download-status" class="download-status" role="status"></p>
  </div>` : '';
  const cards = records.map(record => {
    const links = (Array.isArray(record.links) ? record.links : [record.links]).map(link => {
      const url = safeWebUrl(typeof link === 'string' ? link : link?.url);
      return url ? `<a class="source-link" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(typeof link === 'string' ? '查看来源' : link.label || '查看来源')} <span aria-hidden="true">↗</span></a>` : '';
    }).filter(Boolean).join('');
    const qr = qrImages[record.id] || '';
    const filter = filterable(record);
    const workLocation = filter.work.join('、');
    const eventLocation = record.recruitment_location || '未注明';
    const sourceNote = filter.source === 'wechat_group'
      ? `来源微信群：${escapeHtml(record.source_group)}。`
      : filter.source === 'community'
        ? `由同学自主补充，未经群内老师核实。${safeWebUrl(record.submission_url) ? `<a href="${escapeHtml(safeWebUrl(record.submission_url))}" target="_blank" rel="noopener noreferrer">提交记录与纠错</a>` : ''}`
        : `来源企业微信群：${escapeHtml(record.source_group || '北大医院研究生通知群')}。`;
    return `<article class="record" data-record-id="${escapeHtml(record.id)}" data-filter="${escapeHtml(JSON.stringify(filter))}">
      <div class="record-body">
        <div class="record-badges"><span class="category-badge">${escapeHtml(CATEGORIES[record.category] || '类别待核实')}</span>${filter.source === 'community' ? '<span class="community-badge">同学补充 · 非企业微信官方群汇总</span>' : filter.source === 'wechat_group' ? '<span class="community-badge">微信群汇总 · 非企业微信官方群汇总</span>' : ''}${record.public_eligible === false ? '<span class="local-badge">仅本地保存</span>' : ''}</div>
        <h3>${escapeHtml(record.organization || '单位未注明')}</h3>
        <dl class="times"><div><dt>招聘时间</dt><dd class="recruitment-time">${escapeHtml(record.recruitment_time || '未注明')}</dd></div><div><dt>${workLocation ? '工作地点' : '活动地点'}</dt><dd>${escapeHtml(workLocation || eventLocation)}</dd></div></dl>
        ${links ? `<div class="source-list" aria-label="招聘来源">${links}</div>` : ''}
      </div>
      <details class="original"><summary>详情与原文</summary><div class="record-detail">
        <dl class="times"><div><dt>${record.source_type === 'community' ? '原文发布日期' : '消息时间'}</dt><dd>${escapeHtml(record.message_time || '未注明')}</dd></div><div><dt>${workLocation ? '活动地点' : '工作地点'}</dt><dd>${escapeHtml(workLocation ? eventLocation : '未注明')}</dd></div></dl>
        <div class="original-text">${escapeHtml(record.original_text || '未提供原文')}</div>
        <p class="community-note">${sourceNote}</p>${qr}${!links && !qr ? '<p class="muted">原消息未提供可用链接或二维码。</p>' : ''}
      </div></details>
    </article>`;
  });
  const published = data.meta?.published_at ? String(data.meta.published_at).slice(0, 10) : new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Shanghai' });
  const origin = safeWebUrl(publicUrl);
  const statistics = origin === STATISTICS_PAGE ? `<details id="site-statistics" class="site-statistics"><summary><span>网站统计</span><span class="statistics-toggle" aria-hidden="true"></span></summary><div class="statistics-content"><dl class="statistics-grid"><div><dt>访问人数 <small>估算</small></dt><dd id="statistics-visitors">—</dd></div><div><dt>下载次数</dt><dd id="statistics-downloads">—</dd></div><div><dt>招聘信息</dt><dd id="statistics-records">${records.length}<small>条</small></dd></div></dl><p id="statistics-status" class="statistics-status" role="status">启用 JavaScript 后可查看访问与下载统计。</p><details class="statistics-help"><summary>统计说明</summary><p>访问人数使用匿名标识近似去重，并非实名人数。同一人使用不同设备或浏览器可能重复；同网络、同浏览器也可能合并。</p><p>下载统计包括成功发起的 Excel 下载及备用入口点击，不代表文件已保存完成；直接打开文件链接的下载不在本页计数。</p><p>招聘总数为本页公开收录的通知数量，筛选不会改变总数。访问和下载自 2026-09-08 起累计，可能因网络或浏览器拦截而少计。</p><p>共享计数由 <a href="https://busuanzi.apifox.cn/" target="_blank" rel="noopener noreferrer">不蒜子</a> 提供，服务使用匿名标识及本站固定页面地址进行统计，不发送搜索词或招聘原文。免费公共统计可能有误差或服务中断，仅作参考。</p></details></div></details>` : '';
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="referrer" content="no-referrer"><meta name="description" content="面向北京大学第一医院研究生的医院、公务员与国企、药企及其他企业招聘信息汇总，保留消息时间、招聘时间、主体单位和对应原文来源。由同学整理，非医院官方招聘网站。"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; connect-src 'self'${statistics ? ` ${STATISTICS_API}` : ''}; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>2026-2027 秋招春招汇总</title>${origin ? `<link rel="canonical" href="${escapeHtml(origin)}">` : ''}<style>${css}</style></head><body>
<a class="skip" href="#main">跳到招聘信息</a>
<header class="masthead" id="top"><div class="wrap identity"><span class="brand-name">北大医院研究生就业信息</span><a class="contribute-link" href="#contribution" id="open-contribution">补充招聘信息</a></div></header>
<main id="main" class="wrap main-layout">
  <div class="intro-row"><div><h1>2026-2027 秋招春招汇总</h1><p class="subtitle">更新于 <time datetime="${escapeHtml(published)}">${escapeHtml(published)}</time> · 同学整理，非医院官方发布</p></div>${download}</div>
  <div class="toolbar">
    <div class="search-wrap"><label class="sr-only" for="search">搜索单位、专业或关键词</label><input id="search" type="search" placeholder="搜索单位、专业或关键词" autocomplete="off"><button id="clear-search" type="button" hidden>清除</button></div>
    <div class="toolbar-row"><div class="category-tabs" role="group" aria-label="招聘类别"><button type="button" data-category="" aria-pressed="true">全部</button>${Object.entries(CATEGORIES).map(([key,label]) => `<button type="button" data-category="${key}" aria-pressed="false">${escapeHtml(label)}</button>`).join('')}</div>
    <button id="more-filters" type="button" aria-expanded="false" aria-controls="advanced-filters">更多筛选<span id="active-filters" hidden></span></button></div>
    <div id="advanced-filters" hidden>
      <div class="filter-grid"><label>信息来源<select id="source-filter"><option value="">全部来源</option><option value="official">企业微信群汇总（${officialCount} 条）</option><option value="wechat_group">微信群汇总（${wechatCount} 条）</option><option value="community">同学补充（${communityCount} 条）</option></select></label>
      <label>时间范围<select id="date-mode"><option value="all">全部时间</option><option value="7">未来 7 天（含今天）</option><option value="30">未来 30 天（含今天）</option><option value="custom">自选日期</option><option value="unknown">时间未注明</option></select></label>
      <label>时间类型<select id="event-kind"><option value="">全部类型</option>${Object.entries(EVENT_KINDS).map(([key,label]) => `<option value="${key}">${label}</option>`).join('')}</select></label>
      <label>地点类型<select id="location-scope"><option value="event">宣讲／招聘活动地点</option><option value="work">工作地点</option></select></label>
      <label>城市／地区<select id="location"><option value="">全部地点</option></select></label></div>
      <div id="custom-dates" class="custom-dates" hidden><label>开始日期<input id="date-from" type="date" aria-describedby="filter-error"></label><label>结束日期<input id="date-to" type="date" aria-describedby="filter-error"></label></div>
      <p id="filter-error" role="alert" hidden>开始日期不能晚于结束日期。</p><p class="filter-note">活动时间与地点按同一场次匹配。</p>
    </div>
  </div>
  <section aria-labelledby="results-heading"><div class="section-line"><h2 id="results-heading">招聘信息</h2><div class="results-actions"><span id="count" class="count" role="status">${records.length} 条信息</span><button id="reset-filters" type="button" hidden>清除筛选</button></div></div>
  <noscript><p class="noscript">启用 JavaScript 后可搜索和筛选。</p></noscript><div id="records">${cards.join('\n')}</div><div id="empty" class="empty" ${records.length ? 'hidden' : ''}><h3>${records.length ? '没有匹配的信息' : '暂无可展示的招聘信息'}</h3>${records.length ? '<p>试试其他关键词或清除筛选。</p>' : ''}</div></section>
  ${renderContributionForm()}${adminHtml ? `<details class="operations"><summary>本机整理与发送记录</summary>${adminHtml}</details>` : ''}
</main>
<footer><div class="wrap"><div class="footer-row"><div><p>chym|ltry 同学整理 · 以招聘单位最新公告为准</p><p>消息范围：${escapeHtml(range)}</p></div><div class="footer-links"><a href="mailto:honghaopeng@bjmu.edu.cn">联系与纠错</a><a href="#top">返回顶部 ↑</a></div></div><div class="footer-details"><details id="about" class="about"><summary>来源及筛选说明</summary><p>企业微信群汇总的信息来源为“北大医院研究生通知群”和“北大医院-学生资讯速递群”，每条信息在详情中注明来源群。其他微信群及同学补充单独标记，可按来源筛选。</p><p>日期按报名、宣讲、考核、参访等时间筛选，含起止当天。活动地点与工作地点分别筛选。</p></details>${statistics}</div></div></footer>
<script type="module">${client}</script></body></html>`;
}
