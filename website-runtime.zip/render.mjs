import { readFile } from 'node:fs/promises';
import { CATEGORIES, EVENT_KINDS, SOURCE_TYPES, filterable, sourceCounts, validDate } from './filter.mjs';
import { STATISTICS_PAGE, STATISTICS_API } from './statistics.mjs';
import { renderContributionForm } from './contribute.mjs';
export const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
export function safeWebUrl(value) {
  if (typeof value !== 'string' || /[\u0000-\u0020\u007f]/.test(value)) return null;
  try { const url = new URL(value); return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password ? url.href : null; } catch { return null; }
}

const time = date => `<time datetime="${date}">${date}</time>`;
const textField = (label, value) => `<div><dt>${label}</dt><dd>${escapeHtml(value)}</dd></div>`;
const knownPlace = value => typeof value === 'string' && !/^(未注明|未核实|未知|—|-)?$/.test(value.trim()) ? value.trim() : '';

function eventDetails(event, timeLabel) {
  const { kind, start, end, city } = event;
  const hours = typeof timeLabel === 'string' ? timeLabel.trim() : '';
  const date = start ? `${time(start)}${end && end !== start ? ` 至 ${time(end)}` : ''}`
    : end ? `截至 ${time(end)}` : hours ? '日期未注明' : '时间未注明';
  const hoursHtml = hours ? ` <span class="event-time">${escapeHtml(hours)}</span>` : '';
  const location = knownPlace(event.location);
  const place = [city && !location.includes(city) ? city : '', location || '场地未注明'].filter(Boolean).join(' · ');
  return `<li><span class="event-kind">${EVENT_KINDS[kind]}</span><span class="event-date">${date}${hoursHtml}</span><span class="event-place">${escapeHtml(place)}</span></li>`;
}

function sourceStatus(source, group, links) {
  if (source === 'community' || source === 'wechat_group') return SOURCE_TYPES[source];
  if (group) return links.some(link => link.label === '企业微信群原帖') ? '企业微信群原帖已核实' : '群内已匹配';
  if (source === 'public_verified') return SOURCE_TYPES[source];
  return links.length ? '公开来源' : '';
}

export async function renderPage(data, { excelHref = null, adminHtml = '', qrImages = {}, publicUrl = null } = {}) {
  const records = data.records;
  const css = await readFile(new URL('./theme.css', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./contribute.css', import.meta.url), 'utf8');
  const counts = sourceCounts(records);
  const client = await readFile(new URL('./filter.mjs', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./client.js', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./transfer.mjs', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./statistics.mjs', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./contribute.mjs', import.meta.url), 'utf8') + '\n' + await readFile(new URL('./submission.mjs', import.meta.url), 'utf8') + '\ninstallSubmission(document, window);\nconst statistics = installStatistics(document, window);\ninstallTransfers(document, window, { onDownloadStarted: statistics.downloadStarted });';
  const range = data.meta?.range || '时间范围未注明';
  const download = excelHref ? `<div class="download-tools">
    <div class="download-actions"><a id="download-excel" class="download" href="${escapeHtml(excelHref)}" download="2026-2027 秋招春招汇总.xlsx" aria-describedby="download-status">下载 Excel <span aria-hidden="true">↓</span></a>
    <details class="download-menu"><summary>下载选项</summary><div class="download-options"><a id="download-direct" href="${escapeHtml(excelHref)}" target="_blank" rel="noopener">备用下载</a><button id="copy-download-link" type="button" hidden>复制下载链接</button></div></details></div>
    <p id="download-status" class="download-status" role="status"></p>
  </div>` : '';
  const cards = records.map(record => {
    const links = (Array.isArray(record.links) ? record.links : [record.links]).map(link => {
      const url = safeWebUrl(typeof link === 'string' ? link : link?.url);
      return url ? { url, label: link?.label || '查看来源' } : null;
    }).filter(Boolean);
    const sourceLinks = links.map(({ label, url }) => `<a class="source-link" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)} <span aria-hidden="true">↗</span></a>`).join('');
    const qr = qrImages[record.id] || '';
    const filter = filterable(record);
    const workLocation = filter.work.map(knownPlace).filter(Boolean).join('、');
    const schedule = filter.events.map((event, index) => event.kind && event.kind !== 'application'
      ? eventDetails(event, record.events[index].time) : '').join('');
    const group = ['official', 'wechat_group'].includes(filter.source) ? record.source_group : '';
    const provenance = sourceStatus(filter.source, group, links);
    const messageTime = record.message_time_precision === 'unknown' ? ''
      : record.message_time_precision === 'date' ? validDate(String(record.message_time || '').slice(0, 10))
        : record.message_time;
    const publishedDate = validDate(record.publication_date);
    const legacyLocation = filter.events.length ? '' : knownPlace(record.recruitment_location);
    const submissionUrl = filter.source === 'community' && safeWebUrl(record.submission_url);
    const metadata = [
      group ? textField('来源群', group) : '',
      group ? textField('群消息时间', messageTime || '未注明') : '',
      publishedDate ? `<div><dt>原文发布日期</dt><dd>${time(publishedDate)}</dd></div>` : '',
      legacyLocation ? textField('公告所列地点', legacyLocation) : '',
    ].join('');
    return `<article class="record" data-record-id="${escapeHtml(record.id)}" data-filter="${escapeHtml(JSON.stringify(filter))}">
      <div class="record-body">
        <div class="record-badges"><span class="category-badge">${escapeHtml(CATEGORIES[record.category] || '类别待核实')}</span>${provenance ? `<span class="source-status">${escapeHtml(provenance)}</span>` : ''}${record.public_eligible === false ? '<span class="local-badge">仅本地保存</span>' : ''}</div>
        <h3>${escapeHtml(record.organization || '单位未注明')}</h3>
        <dl class="times"><div><dt>招聘时间</dt><dd class="recruitment-time">${escapeHtml(record.recruitment_time || '未注明')}</dd></div>${textField('工作地点', workLocation || '未注明')}</dl>
        ${schedule ? `<ul class="event-list" aria-label="活动时间和场地">${schedule}</ul>` : ''}
        ${sourceLinks ? `<div class="source-list" aria-label="招聘来源和申请入口">${sourceLinks}</div>` : ''}
      </div>
      <details class="original"><summary>详情与来源</summary><div class="record-detail">
        ${metadata ? `<dl class="times source-metadata">${metadata}</dl>` : ''}
        <div class="original-text">${escapeHtml(record.original_text || '未提供招聘内容')}</div>
        ${submissionUrl ? `<p class="community-note"><a href="${escapeHtml(submissionUrl)}" target="_blank" rel="noopener noreferrer">提交记录与纠错</a></p>` : ''}${qr}${!links.length && !qr ? '<p class="muted">暂无可用的公开链接或二维码。</p>' : ''}
      </div></details>
    </article>`;
  });
  const published = data.meta?.published_at ? String(data.meta.published_at).slice(0, 10) : new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Shanghai' });
  const origin = safeWebUrl(publicUrl);
  const statistics = origin === STATISTICS_PAGE ? `<details id="site-statistics" class="site-statistics"><summary><span>网站统计</span><span class="statistics-toggle" aria-hidden="true"></span></summary><div class="statistics-content"><dl class="statistics-grid"><div><dt>访问人数 <small>估算</small></dt><dd id="statistics-visitors">—</dd></div><div><dt>下载次数</dt><dd id="statistics-downloads">—</dd></div><div><dt>招聘信息</dt><dd id="statistics-records">${records.length}<small>条</small></dd></div></dl><p id="statistics-status" class="statistics-status" role="status">启用 JavaScript 后可查看访问与下载统计。</p><details class="statistics-help"><summary>统计说明</summary><p>访问人数使用匿名标识近似去重，并非实名人数。同一人使用不同设备或浏览器可能重复；同网络、同浏览器也可能合并。</p><p>下载统计包括成功发起的 Excel 下载及备用入口点击，不代表文件已保存完成；直接打开文件链接的下载不在本页计数。</p><p>招聘总数为本页公开收录的通知数量，筛选不会改变总数。访问和下载自 2026-09-08 起累计，可能因网络或浏览器拦截而少计。</p><p>共享计数由 <a href="https://busuanzi.apifox.cn/" target="_blank" rel="noopener noreferrer">不蒜子</a> 提供，服务使用匿名标识及本站固定页面地址进行统计，不发送搜索词或招聘原文。免费公共统计可能有误差或服务中断，仅作参考。</p></details></div></details>` : '';
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="referrer" content="no-referrer"><meta name="description" content="面向北京大学第一医院研究生整理的医院、公务员与国企、药企及其他企业招聘信息，提供招聘时间、工作地点、活动场地与来源。"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; connect-src 'self'${statistics ? ` ${STATISTICS_API}` : ''}; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>2026-2027 秋招春招汇总</title>${origin ? `<link rel="canonical" href="${escapeHtml(origin)}">` : ''}<style>${css}</style></head><body>
<a class="skip" href="#main">跳到招聘信息</a>
<header class="masthead" id="top"><div class="wrap identity"><span class="brand-name">北大医院研究生就业信息</span><a class="contribute-link" href="#contribution" id="open-contribution">补充招聘信息</a></div></header>
<main id="main" class="wrap main-layout">
  <div class="intro-row"><div><h1>2026-2027 秋招春招汇总</h1><p class="subtitle">更新于 <time datetime="${escapeHtml(published)}">${escapeHtml(published)}</time> · 同学整理，非医院官方发布</p></div>${download}</div>
  <div class="toolbar">
    <div class="search-wrap"><label class="sr-only" for="search">搜索单位、专业或关键词</label><input id="search" type="search" placeholder="搜索单位、专业或关键词" autocomplete="off"><button id="clear-search" type="button" hidden>清除</button></div>
    <div class="toolbar-row"><div class="category-tabs" role="group" aria-label="招聘类别"><button type="button" data-category="" aria-pressed="true">全部</button>${Object.entries(CATEGORIES).map(([key,label]) => `<button type="button" data-category="${key}" aria-pressed="false">${escapeHtml(label)}</button>`).join('')}</div>
    <button id="more-filters" type="button" aria-expanded="false" aria-controls="advanced-filters">更多筛选<span id="active-filters" hidden></span></button></div>
    <div id="advanced-filters" hidden>
      <div class="filter-grid"><label>信息来源<select id="source-filter"><option value="">全部来源</option>${Object.entries(SOURCE_TYPES).map(([key, label]) => `<option value="${key}">${escapeHtml(label)}（${counts[`${key}_records`] || 0} 条）</option>`).join('')}</select></label>
      <label>时间范围<select id="date-mode"><option value="all">全部时间</option><option value="7">未来 7 天（含今天）</option><option value="30">未来 30 天（含今天）</option><option value="custom">自选日期</option><option value="unknown">时间未注明</option></select></label>
      <label>时间类型<select id="event-kind"><option value="">全部类型</option>${Object.entries(EVENT_KINDS).map(([key,label]) => `<option value="${key}">${label}</option>`).join('')}</select></label>
      <label>地点类型<select id="location-scope"><option value="event">宣讲／招聘活动地点</option><option value="work">工作地点</option></select></label>
      <label>城市／地区<select id="location"><option value="">全部地点</option></select></label></div>
      <div id="custom-dates" class="custom-dates" hidden><label>开始日期<input id="date-from" type="date" aria-describedby="filter-error"></label><label>结束日期<input id="date-to" type="date" aria-describedby="filter-error"></label></div>
      <p id="filter-error" role="alert" hidden>开始日期不能晚于结束日期。</p><p class="filter-note">活动时间与地点按同一场次匹配。</p>
    </div>
  </div>
  <section aria-labelledby="results-heading"><div class="section-line"><h2 id="results-heading">招聘信息</h2><div class="results-actions"><span id="count" class="count" role="status">${records.length} 条信息</span><button id="reset-filters" type="button" hidden>清除筛选</button></div></div>
  <noscript><p class="noscript">启用 JavaScript 后可搜索和筛选。</p></noscript><div id="records">${cards.join('\n')}</div><div id="empty" class="empty" ${records.length ? 'hidden' : ''}><h3>${records.length ? '没有匹配的信息' : '暂无可展示的招聘信息'}</h3>${records.length ? '<p>试试其他关键词或清除筛选。</p>' : ''}</div></section>
  ${renderContributionForm()}${adminHtml ? `<details class="operations"><summary>本机整理与发送记录</summary>${adminHtml}</details>` : ''}
</main>
<footer><div class="wrap"><div class="footer-row"><div><p>chym|ltry 同学整理 · 以招聘单位最新公告为准</p><p>消息范围：${escapeHtml(range)}</p></div><div class="footer-links"><a href="mailto:honghaopeng@bjmu.edu.cn">联系与纠错</a><a href="#top">返回顶部 ↑</a></div></div><div class="footer-details"><details id="about" class="about"><summary>来源及筛选说明</summary><p>“群内已匹配”表示已在企业微信群找到对应消息。详情显示已核实的群名和消息时间。带“企业微信群原帖”标签的链接可以查看已核对的群内推送。</p><p>“公开权威来源”包括招聘单位、主办方或高校发布的消息。可按报名、宣讲等日期筛选，也可分别筛选工作地点和活动地点。</p></details>${statistics}</div></div></footer>
<script type="module">${client}</script></body></html>`;
}
