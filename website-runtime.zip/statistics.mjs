// Keep the page keys stable across publications so the shared totals continue.
export const STATISTICS_PAGE = 'https://chymlltrn.github.io/pkuh1-career-bulletin/';
export const STATISTICS_API = 'https://bsz.dusays.com';
export const STATISTICS_DOWNLOAD_PAGE = `${STATISTICS_PAGE}recruitment.xlsx`;
const STATISTICS_IDENTITY = 'pkuh1-career-bulletin:busuanzi-identity:v1';
const validIdentity = value => typeof value === 'string' && /^[A-Za-z0-9._~-]{20,256}$/.test(value);

export function installStatistics(document, window) {
  const panel = document.getElementById('site-statistics');
  const inactive = { ready: Promise.resolve(), downloadStarted() {} };
  if (!panel) return inactive;
  if (panel.statisticsController) return panel.statisticsController;
  panel.open = Boolean(window.matchMedia?.('(min-width: 901px)').matches);
  const notice = document.getElementById('statistics-status');
  const fields = {
    visit: document.getElementById('statistics-visitors'),
    download: document.getElementById('statistics-downloads'),
  };
  const page = new window.URL(STATISTICS_PAGE);
  const current = new window.URL(window.location.href);
  if (current.origin !== page.origin || ![page.pathname, `${page.pathname}index.html`].includes(current.pathname)) {
    notice.textContent = '本地预览不计入访问与下载。';
    panel.statisticsController = inactive;
    return inactive;
  }
  const readOnly = current.searchParams.get('stats') === 'off' || window.navigator.globalPrivacyControl === true || window.navigator.doNotTrack === '1';
  let identity;
  if (!readOnly) {
    try { identity = window.localStorage.getItem(STATISTICS_IDENTITY); } catch { /* Keep the service's anonymous identity in memory if storage is unavailable. */ }
    if (!validIdentity(identity)) identity = undefined;
  }
  const failures = new Set();
  function updateNotice() {
    if (failures.size) notice.textContent = `${[...failures].map(key => key === 'visit' ? '访问' : '下载').join('、')}统计暂不可用，可稍后刷新。`;
    else notice.textContent = readOnly ? '仅查看统计，本次访问不计数。' : '自 2026-09-08 起累计 · 仅供参考';
  }
  async function request(action, record = false) {
    const headers = { 'x-bsz-referer': action === 'visit' ? STATISTICS_PAGE : STATISTICS_DOWNLOAD_PAGE };
    if (identity && !readOnly) headers.Authorization = `Bearer ${identity}`;
    const abort = new window.AbortController();
    const timeout = window.setTimeout(() => abort.abort(), 8000);
    try {
      const response = await window.fetch(`${STATISTICS_API}/api`, {
        method: record && !readOnly ? 'POST' : 'GET', headers,
        signal: abort.signal, mode: 'cors', credentials: 'omit', cache: 'no-store',
        referrerPolicy: 'no-referrer', keepalive: record,
      });
      if (!response.ok) throw new Error('Statistics unavailable');
      const result = await response.json();
      const value = result.data?.[action === 'visit' ? 'page_uv' : 'page_pv'];
      if (result.success !== true || !Number.isSafeInteger(value) || value < 0) throw new Error('Invalid statistic');
      const received = response.headers.get('Set-Bsz-Identity');
      if (!readOnly && validIdentity(received)) {
        identity = received;
        try { window.localStorage.setItem(STATISTICS_IDENTITY, identity); } catch { /* In-memory identity still deduplicates this page's events. */ }
      }
      fields[action].textContent = value.toLocaleString('zh-CN');
      fields[action].removeAttribute('title');
      failures.delete(action);
    } catch {
      fields[action].textContent = '—';
      fields[action].setAttribute('title', '统计服务暂不可用');
      failures.add(action);
    } finally {
      window.clearTimeout(timeout);
      updateNotice();
    }
  }
  notice.textContent = '正在读取统计…';
  // Finish identifying the visitor before reading or incrementing the download page.
  const ready = request('visit', true).then(() => request('download'));
  let downloads = ready;
  const controller = {
    ready,
    downloadStarted() {
      // Never block a save, retry an uncertain increment, or claim the file was saved.
      if (!readOnly) downloads = downloads.then(() => request('download', true));
      return downloads;
    },
  };
  panel.statisticsController = controller;
  const direct = document.getElementById('download-direct');
  direct?.addEventListener('click', event => {
    if (event.defaultPrevented || event.button !== 0) return;
    const url = new window.URL(direct.getAttribute('href'), current.href);
    if (url.href === STATISTICS_DOWNLOAD_PAGE) void controller.downloadStarted();
  });
  return controller;
}
