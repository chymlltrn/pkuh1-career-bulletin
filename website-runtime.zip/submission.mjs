export const SUBMISSION_REPOSITORY = 'https://github.com/chymlltrn/pkuh1-career-bulletin';
export const SUBMISSION_MARKER = '<!-- recruitment-submission:v1 -->';

export function makeSubmissionIssue(payload) {
  const title = `[招聘补充] ${payload.mode === 'link' ? '微信公开推送' : payload.organization}`;
  const body = `${SUBMISSION_MARKER}\n同学自主提供的公开招聘信息，非企业微信官方群汇总。\n请保留下面的提交内容；如需修改信息，可返回网页重新生成后替换。\n\n\`\`\`json\n${JSON.stringify(payload, null, 2)}\n\`\`\`\n`;
  const url = new URL(`${SUBMISSION_REPOSITORY}/issues/new`);
  url.searchParams.set('title', title.slice(0, 240));
  url.searchParams.set('body', body);
  const fitsUrl = url.href.length <= 7000;
  if (!fitsUrl) url.searchParams.delete('body');
  return { body, url: url.href, fitsUrl };
}

export function installSubmission(document, window) {
  const panel = document.getElementById('contribution');
  const form = document.getElementById('contribution-form');
  if (!panel || !form) return;
  document.getElementById('open-contribution')?.addEventListener('click', () => { panel.open = true; });
  if (window.location.hash === '#contribution') panel.open = true;
  const handoff = document.createElement('section');
  handoff.className = 'submission-handoff';
  handoff.hidden = true;
  form.append(handoff);
  form.addEventListener('input', () => { handoff.hidden = true; handoff.replaceChildren(); });
  installContributionForm(document, window, { onSubmit(payload) {
    const draft = makeSubmissionIssue(payload);
    handoff.replaceChildren();
    handoff.hidden = false;
    const heading = document.createElement('h3');
    heading.textContent = '确认后提交';
    const instruction = document.createElement('p');
    instruction.textContent = draft.fitsUrl
      ? '打开下方提交页，登录 GitHub，核对内容后点击“Create”完成提交。通常几分钟内可在提交记录中看到处理结果。'
      : '原文较长：先复制下方提交内容，再打开提交页，粘贴到正文框，核对后点击“Create”。';
    handoff.append(heading, instruction);
    if (!draft.fitsUrl) {
      const text = document.createElement('textarea');
      text.value = draft.body; text.readOnly = true;
      text.setAttribute('aria-label', '完整提交内容，复制后粘贴到 GitHub 正文框');
      const copy = document.createElement('button');
      copy.type = 'button'; copy.textContent = '复制提交内容';
      copy.addEventListener('click', async () => {
        try { await window.navigator.clipboard.writeText(draft.body); copy.textContent = '已复制'; }
        catch { text.focus(); text.select(); copy.textContent = '请复制已选中的内容'; }
      });
      handoff.append(text, copy);
    }
    const link = document.createElement('a');
    link.href = draft.url; link.target = '_blank'; link.rel = 'noopener noreferrer';
    link.textContent = '打开 GitHub 确认提交 ↗';
    handoff.append(link);
    return { message: '提交内容已准备好，尚未发送。请使用下方入口完成提交。' };
  } });
}
