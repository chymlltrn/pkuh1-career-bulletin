export function installTransfers(document, window, { onDownloadStarted = () => {} } = {}) {
  const status = document.getElementById('download-status');
  const announce = message => { if (status) status.textContent = message; };

  document.addEventListener('copy', event => {
    if ([event.target, document.activeElement].some(element => element?.closest?.('input, textarea'))) return;
    const text = window.getSelection()?.toString();
    if (!text || !event.clipboardData) return;
    try {
      event.clipboardData.clearData();
      event.clipboardData.setData('text/plain', text);
      event.preventDefault();
    } catch {
      // Leave the browser's normal copy behavior available if clipboard writing is denied.
    }
  });

  const download = document.getElementById('download-excel');
  if (!download) return;
  const fileUrl = () => new window.URL(download.getAttribute('href'), window.location.href);
  let downloading = false;

  download.addEventListener('click', async event => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const url = fileUrl();
    if (!['http:', 'https:'].includes(window.location.protocol) || !['http:', 'https:'].includes(url.protocol) || url.origin !== window.location.origin) return;
    event.preventDefault();
    if (downloading) return;
    downloading = true;
    download.setAttribute('aria-busy', 'true');
    announce('正在准备 Excel 下载…');
    const controller = new window.AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 20000);
    let objectUrl;
    let cleanupScheduled = false;
    try {
      const response = await window.fetch(url.href, { signal: controller.signal, credentials: 'same-origin' });
      if (!response.ok || /text\/html/i.test(response.headers.get('content-type') || '')) throw new Error('Invalid file response');
      const bytes = new Uint8Array(await response.arrayBuffer());
      if (bytes.length < 4 || bytes[0] !== 0x50 || bytes[1] !== 0x4b || bytes[2] !== 0x03 || bytes[3] !== 0x04) throw new Error('Invalid Excel file');
      objectUrl = window.URL.createObjectURL(new window.Blob([bytes], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      }));
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = download.getAttribute('download') || '2026-2027 秋招春招汇总.xlsx';
      link.hidden = true;
      document.body.append(link);
      try { link.click(); } finally { link.remove(); }
      // Keep the object URL alive while Safari and Chrome begin saving the file.
      window.setTimeout(() => window.URL.revokeObjectURL(objectUrl), 60000);
      cleanupScheduled = true;
      announce('已发起下载。若未出现保存提示，请使用“备用下载”。');
      try { onDownloadStarted(); } catch { /* Statistics must not interrupt a download. */ }
    } catch {
      announce('暂时无法准备下载，请使用“备用下载”重试，或复制下载链接在浏览器中打开。');
    } finally {
      window.clearTimeout(timeout);
      if (objectUrl && !cleanupScheduled) window.URL.revokeObjectURL(objectUrl);
      download.removeAttribute('aria-busy');
      downloading = false;
    }
  });

  const copyLink = document.getElementById('copy-download-link');
  if (copyLink && window.navigator.clipboard?.writeText) copyLink.hidden = false;
  copyLink?.addEventListener('click', async () => {
    const url = fileUrl();
    if (!['http:', 'https:'].includes(url.protocol) || url.origin !== window.location.origin) {
      announce('请在公开网页上复制下载链接；本地页面可直接下载文件。');
      return;
    }
    try {
      await window.navigator.clipboard.writeText(url.href);
      announce('下载链接已复制，可粘贴到浏览器地址栏打开。');
    } catch {
      announce('浏览器未允许复制，请右键“备用下载”并选择复制链接地址。');
    }
  });
}
